# V5.16 Allocation Explanation Report

Generated at: `2026-09-02T16:04:41`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-09-01`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| SGOV | 22.39% | -8.32% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| XBI | 8.59% | 1.07% | Selected by latest signal basket | XBI received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EWT | 8.15% | 2.04% | Selected by latest signal basket | EWT received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| AVUV | 6.89% | -0.54% | Carryover / turnover-constrained holding | AVUV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| CIBR | 6.66% | 2.59% | Selected by latest signal basket | CIBR received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| THD | 6.12% | -0.48% | Carryover / turnover-constrained holding | THD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| KIE | 6.11% | 2.80% | Selected by latest signal basket | KIE received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| VTV | 5.21% | -0.41% | Carryover / turnover-constrained holding | VTV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| SPYD | 4.93% | -0.39% | Carryover / turnover-constrained holding | SPYD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| JETS | 3.92% | -0.31% | Carryover / turnover-constrained holding | JETS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| AVDV | 3.75% | -0.30% | Carryover / turnover-constrained holding | AVDV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EWS | 3.70% | 3.70% | Selected by latest signal basket | EWS received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| PKW | 3.61% | 3.61% | Selected by latest signal basket | PKW received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XLV | 3.52% | 3.52% | Selected by latest signal basket | XLV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XLE | 3.25% | 3.25% | Selected by latest signal basket | XLE received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XOP | 3.21% | -0.25% | Carryover / turnover-constrained holding | XOP is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SGOV | 22.39% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.0 | 0.1990437270832773 | 0.2238904970179575 |
| XBI | 8.59% | 27.006 | True | True | True | True | 29.89% | Selected by latest signal basket | 0.0831549803762045 | 1.14 | 0.1009345588690501 | 0.1009345588690501 | 0.0763242016124178 | 0.085851805951933 |
| EWT | 8.15% | 25.969 | True | True | True | True | 41.33% | Selected by latest signal basket | 0.119999999260199 | 1.0933333333333333 | 0.1199999999999999 | 0.1199999999999999 | 0.0724315209875667 | 0.0814731992377135 |
| AVUV | 6.89% | 13.014 | False | True | True | True | 11.70% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0612879630261752 | 0.0689385830150153 |
| CIBR | 6.66% | 28.116 | True | True | True | True | 32.52% | Selected by latest signal basket | 0.1199999948718301 | 1.1166666666666667 | 0.1199999999999999 | 0.1199999999999999 | 0.0592386639080846 | 0.066633468431345 |
| THD | 6.12% | 12.467 | True | True | True | True | 18.02% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0544347182269949 | 0.0612298427961777 |
| KIE | 6.11% | 16.883 | True | True | True | True | 19.84% | Selected by latest signal basket | 0.1199999989736289 | 0.9766666666666668 | 0.12 | 0.12 | 0.0543116638263722 | 0.0610914274272566 |
| VTV | 5.21% | 14.923 | True | True | True | True | 9.55% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0462895611925977 | 0.0520679200194929 |
| SPYD | 4.93% | 13.37 | True | True | True | True | 12.57% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0437855358232106 | 0.0492513153833514 |
| JETS | 3.92% | 8.355 | False | True | True | True | 33.22% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0348287775292199 | 0.0391764785849413 |
| AVDV | 3.75% | 11.324 | True | True | True | True | 17.18% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0333368983556865 | 0.0374983670737286 |
| EWS | 3.70% | 21.281 | True | True | True | True | 15.85% | Selected by latest signal basket | 0.1199999986046233 | 1.07 | 0.1199999999999999 | 0.1199999999999999 | 0.0328624250507885 | 0.0369646649289183 |
| PKW | 3.61% | 15.783 | True | True | True | True | 11.06% | Selected by latest signal basket | 0.1199999970536835 | 0.93 | 0.1172766599528531 | 0.1172766599528531 | 0.032116628732562 | 0.0361257703261659 |
| XLV | 3.52% | 15.675 | True | True | True | True | 19.46% | Selected by latest signal basket | 0.1199999974349093 | 0.9066666666666668 | 0.1143342347927456 | 0.1143342347927456 | 0.0313108351801321 | 0.0352193889918177 |
| XLE | 3.25% | 15.604 | True | True | True | True | 22.63% | Selected by latest signal basket | 0.1199999997250638 | 0.8366666666666667 | 0.1055069593124233 | 0.1055069593124233 | 0.0288934545228425 | 0.0325002449887729 |
| XOP | 3.21% | 15.4 | True | True | True | True | 29.19% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0285260933196065 | 0.0320870258254118 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 22.39% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 81.46% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 0.00% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 10.12% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 22.59% | One-way movement at the latest rebalance. |
| Turnover before pruning | 20.00% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 2.59% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 74.65% | 21.92% | 13.97% | 1.346 | -12.31% | 0.0826% | 1.780 | 1.780 | 1.313 | 0.313 | 1.905 |
| SPY | 86.42% | 24.78% | 15.45% | 1.381 | -18.76% | 0.0926% | 1.321 | 1.321 | 1.330 | 0.330 | 2.069 |
| QQQ | 101.41% | 28.26% | 20.64% | 1.212 | -22.77% | 0.1072% | 1.241 | 1.241 | 1.264 | 0.264 | 1.795 |
| VTI | 87.39% | 25.01% | 15.59% | 1.382 | -19.30% | 0.0934% | 1.296 | 1.296 | 1.325 | 0.325 | 2.063 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| XLE | XOP | 0.931 |
| VTV | PKW | 0.907 |
| AVUV | PKW | 0.880 |
| VTV | SPYD | 0.850 |
| AVUV | VTV | 0.835 |
| SPYD | PKW | 0.804 |
| AVUV | SPYD | 0.779 |
| AVDV | EWS | 0.714 |
| JETS | PKW | 0.713 |
| AVUV | JETS | 0.698 |
| KIE | PKW | 0.694 |
| VTV | AVDV | 0.688 |
| KIE | VTV | 0.683 |
| VTV | XLV | 0.672 |
| EWT | AVDV | 0.669 |
| KIE | SPYD | 0.655 |
| VTV | JETS | 0.655 |
| AVDV | PKW | 0.650 |
| AVUV | AVDV | 0.645 |
| AVUV | KIE | 0.597 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
