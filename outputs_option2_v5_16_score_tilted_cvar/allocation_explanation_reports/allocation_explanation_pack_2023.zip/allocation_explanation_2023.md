# V5.16 Allocation Explanation Report

Generated at: `2026-08-06T01:33:20`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-08-05`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| SGOV | 14.04% | -0.39% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| EIS | 10.67% | -0.29% | Carryover / turnover-constrained holding | EIS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| MLPA | 9.47% | -0.26% | Carryover / turnover-constrained holding | MLPA is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XBI | 6.82% | -0.19% | Carryover / turnover-constrained holding | XBI is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| LIT | 6.49% | -0.18% | Carryover / turnover-constrained holding | LIT is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EWY | 6.11% | -0.17% | Carryover / turnover-constrained holding | EWY is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| THD | 6.08% | -0.17% | Carryover / turnover-constrained holding | THD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| SPYD | 5.85% | -0.16% | Carryover / turnover-constrained holding | SPYD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| KIE | 5.69% | 2.59% | Selected by latest signal basket | KIE received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| DIV | 5.35% | -0.15% | Carryover / turnover-constrained holding | DIV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| GLDM | 5.27% | -0.14% | Carryover / turnover-constrained holding | GLDM is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XAR | 4.58% | -0.13% | Carryover / turnover-constrained holding | XAR is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| AVDV | 4.16% | -0.11% | Carryover / turnover-constrained holding | AVDV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XLU | 3.34% | -0.09% | Carryover / turnover-constrained holding | XLU is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EPOL | 3.04% | 3.04% | Selected by latest signal basket | EPOL received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| CIBR | 3.04% | 3.04% | Selected by latest signal basket | CIBR received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SGOV | 14.04% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.0 | 0.1144972765941769 | 0.1404182100077103 |
| EIS | 10.67% | -4.574 | False | False | False | True | 27.39% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0869776602508992 | 0.1066684529657293 |
| MLPA | 9.47% | 13.38 | True | True | True | True | 15.61% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0772428672468564 | 0.0947298091037598 |
| XBI | 6.82% | 13.15 | True | True | True | True | 31.12% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0556131504658014 | 0.0682033605827656 |
| LIT | 6.49% | -7.588 | False | False | False | True | 35.09% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0529413546943074 | 0.0649266994175477 |
| EWY | 6.11% | 0.27 | False | True | False | True | 82.99% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.049861693445907 | 0.0611498364842638 |
| THD | 6.08% | 13.932 | True | True | True | True | 20.84% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0495509568844201 | 0.0607687525576776 |
| SPYD | 5.85% | 15.061 | True | True | True | True | 12.22% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.047665844474854 | 0.0584568712790266 |
| KIE | 5.69% | 15.934 | True | True | True | True | 20.76% | Selected by latest signal basket | 0.1199999979670375 | 0.8366666666666667 | 0.1054258460331603 | 0.1054258460331603 | 0.0463876935297405 | 0.0568893609139668 |
| DIV | 5.35% | 12.677 | True | True | True | True | 11.45% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0436583479802946 | 0.0535421213293599 |
| GLDM | 5.27% | -8.028 | True | False | False | False | 25.24% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0429486978265069 | 0.0526718141282572 |
| XAR | 4.58% | 10.198 | True | True | True | True | 33.16% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0373417253209332 | 0.0457954842607296 |
| AVDV | 4.16% | 11.612 | True | True | True | True | 18.73% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0339201435831758 | 0.0415992937721656 |
| XLU | 3.34% | -1.758 | False | False | False | True | 16.54% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0272572312698837 | 0.0334279708525217 |
| EPOL | 3.04% | 18.097 | True | True | True | True | 24.67% | Selected by latest signal basket | 0.1199999963788586 | 1.07 | 0.12 | 0.12 | 0.0247686330562728 | 0.0303759811722589 |
| CIBR | 3.04% | 34.272 | True | True | True | True | 33.21% | Selected by latest signal basket | 0.111849082171239 | 1.163333333333333 | 0.12 | 0.12 | 0.0247686330562728 | 0.0303759811722589 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 14.04% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 81.99% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 0.00% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 13.02% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 8.66% | One-way movement at the latest rebalance. |
| Turnover before pruning | 20.00% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 0.00% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 74.81% | 21.96% | 15.43% | 1.234 | -14.87% | 0.0835% | 1.477 | 1.477 | 1.280 | 0.280 | 1.747 |
| SPY | 87.57% | 25.05% | 15.57% | 1.385 | -18.76% | 0.0935% | 1.336 | 1.336 | 1.328 | 0.328 | 2.071 |
| QQQ | 103.18% | 28.65% | 20.77% | 1.221 | -22.77% | 0.1085% | 1.259 | 1.259 | 1.265 | 0.265 | 1.804 |
| VTI | 86.97% | 24.91% | 15.73% | 1.366 | -19.30% | 0.0932% | 1.290 | 1.290 | 1.318 | 0.318 | 2.035 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| SPYD | DIV | 0.903 |
| AVDV | EPOL | 0.687 |
| SPYD | KIE | 0.657 |
| KIE | DIV | 0.631 |
| LIT | AVDV | 0.623 |
| SPYD | XLU | 0.621 |
| XAR | AVDV | 0.609 |
| MLPA | DIV | 0.609 |
| EWY | AVDV | 0.600 |
| DIV | XLU | 0.587 |
| DIV | AVDV | 0.576 |
| THD | AVDV | 0.573 |
| SPYD | AVDV | 0.570 |
| EIS | AVDV | 0.550 |
| LIT | EWY | 0.535 |
| MLPA | SPYD | 0.516 |
| XBI | XAR | 0.515 |
| XAR | CIBR | 0.512 |
| EWY | THD | 0.495 |
| EIS | CIBR | 0.489 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
