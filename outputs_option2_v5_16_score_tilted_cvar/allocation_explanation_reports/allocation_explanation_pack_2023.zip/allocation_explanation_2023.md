# V5.16 Allocation Explanation Report

Generated at: `2026-11-01T23:51:11`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-10-30`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| SGOV | 45.93% | 9.08% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| JQUA | 6.77% | 1.12% | Selected by latest signal basket | JQUA received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XLV | 6.67% | 1.17% | Selected by latest signal basket | XLV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| CIBR | 6.00% | -1.15% | Carryover / turnover-constrained holding | CIBR is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XBI | 5.51% | -1.05% | Carryover / turnover-constrained holding | XBI is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| VTV | 4.82% | 2.13% | Selected by latest signal basket | VTV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XLE | 3.05% | 3.05% | Selected by latest signal basket | XLE received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| WCLD | 3.05% | 3.05% | Selected by latest signal basket | WCLD received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| BKLN | 2.95% | 2.95% | Selected by latest signal basket | BKLN received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XYLD | 2.86% | -0.55% | Carryover / turnover-constrained holding | XYLD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| ARKG | 2.86% | -0.55% | Carryover / turnover-constrained holding | ARKG is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XLP | 2.73% | 2.73% | Selected by latest signal basket | XLP received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| IBB | 2.39% | 2.39% | Selected by latest signal basket | IBB received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XOP | 2.33% | -0.45% | Carryover / turnover-constrained holding | XOP is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EFAV | 2.09% | 2.09% | Selected by latest signal basket | EFAV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SGOV | 45.93% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.18036048689138584 | 0.4501586303200793 | 0.45926276778051744 |
| JQUA | 6.77% | 18.828 | True | True | True | True | 10.55% | Selected by latest signal basket | 0.11999997097509263 | 1.07 | 0.12 | 0.0983567415730337 | 0.06634931500887054 | 0.06769118261633407 |
| XLV | 6.67% | 26.279 | True | True | True | True | 17.34% | Selected by latest signal basket | 0.11999999116876398 | 1.14 | 0.12 | 0.0983567415730337 | 0.06536576112272098 | 0.06668773705383725 |
| CIBR | 6.00% | 25.795 | False | True | True | True | 36.21% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.05882312597251179 | 0.06001278177079257 |
| XBI | 5.51% | 14.499 | False | True | True | True | 30.57% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.05400188807175616 | 0.05509403776969461 |
| VTV | 4.82% | 18.355 | True | True | True | True | 7.99% | Selected by latest signal basket | 0.11999999211320235 | 1.0466666666666666 | 0.12 | 0.0983567415730337 | 0.047255112952577526 | 0.04821081393230304 |
| XLE | 3.05% | 23.748 | True | True | True | True | 21.61% | Selected by latest signal basket | 0.1199999994692151 | 1.0933333333333333 | 0.12 | 0.0983567415730337 | 0.02987675431051633 | 0.030480990372637976 |
| WCLD | 3.05% | 31.4 | True | True | True | True | 38.16% | Selected by latest signal basket | 0.1199998556759335 | 1.1633333333333333 | 0.12 | 0.0983567415730337 | 0.02987675431051633 | 0.030480990372637976 |
| BKLN | 2.95% | 15.791 | True | True | True | True | 2.11% | Selected by latest signal basket | 0.11999999378251221 | 0.93 | 0.11617104525333996 | 0.09521837896876635 | 0.02892344814191593 | 0.029508404266219545 |
| XYLD | 2.86% | 15.204 | False | True | True | True | 5.11% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.02800066796083072 | 0.028566961513657264 |
| ARKG | 2.86% | 42.175 | True | True | True | True | 53.08% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.02800066796083072 | 0.028566961513657264 |
| XLP | 2.73% | 15.56 | True | True | True | True | 15.83% | Selected by latest signal basket | 0.11999999313745634 | 0.86 | 0.1074269880837337 | 0.08805140420767639 | 0.026746414410803974 | 0.027287341579514842 |
| IBB | 2.39% | 24.918 | True | True | True | True | 26.43% | Selected by latest signal basket | 0.08109287116628812 | 1.1166666666666667 | 0.09426272281718101 | 0.0772614522341665 | 0.023468868418743488 | 0.0239435095557428 |
| XOP | 2.33% | 20.117 | True | True | True | True | 26.84% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.02287876729936625 | 0.02334147406180398 |
| EFAV | 2.09% | 16.724 | True | True | True | True | 9.88% | Selected by latest signal basket | 0.07890725757880991 | 1.0 | 0.08213924384574522 | 0.06732456983283634 | 0.020450450063591002 | 0.020864045840649357 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 45.93% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 54.18% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 18.04% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 8.97% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 29.77% | One-way movement at the latest rebalance. |
| Turnover before pruning | 28.17% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 1.59% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 55.62% | 15.95% | 12.73% | 1.070 | -11.45% | 0.0620% | 1.393 | 1.393 | 1.243 | 0.243 | 1.480 |
| SPY | 88.55% | 23.65% | 15.22% | 1.339 | -18.76% | 0.0888% | 1.261 | 1.261 | 1.317 | 0.317 | 2.003 |
| QQQ | 101.11% | 26.34% | 20.57% | 1.142 | -22.77% | 0.1012% | 1.157 | 1.157 | 1.248 | 0.248 | 1.678 |
| VTI | 87.90% | 23.50% | 15.37% | 1.321 | -19.30% | 0.0885% | 1.218 | 1.218 | 1.308 | 0.308 | 1.968 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| XLE | XOP | 0.932 |
| XBI | IBB | 0.900 |
| JQUA | VTV | 0.863 |
| CIBR | WCLD | 0.840 |
| JQUA | XYLD | 0.826 |
| XBI | ARKG | 0.787 |
| ARKG | IBB | 0.751 |
| VTV | XYLD | 0.738 |
| XLV | IBB | 0.733 |
| JQUA | CIBR | 0.728 |
| JQUA | WCLD | 0.673 |
| XLV | VTV | 0.664 |
| BKLN | XYLD | 0.652 |
| VTV | IBB | 0.626 |
| JQUA | BKLN | 0.626 |
| JQUA | IBB | 0.609 |
| JQUA | ARKG | 0.602 |
| VTV | BKLN | 0.593 |
| VTV | EFAV | 0.588 |
| CIBR | XYLD | 0.577 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
