# V5.16 Allocation Explanation Report

Generated at: `2026-10-01T19:03:26`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-09-30`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| SGOV | 36.84% | 12.68% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| EWT | 8.70% | 0.89% | Selected by latest signal basket | EWT received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| CIBR | 7.15% | 1.62% | Selected by latest signal basket | CIBR received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XBI | 6.56% | -1.04% | Carryover / turnover-constrained holding | XBI is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| JQUA | 5.65% | 2.34% | Selected by latest signal basket | JQUA received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XLV | 5.49% | 2.10% | Selected by latest signal basket | XLV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EWY | 4.07% | -0.65% | Carryover / turnover-constrained holding | EWY is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| AVDV | 3.72% | -0.59% | Carryover / turnover-constrained holding | AVDV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| ARKG | 3.40% | 3.40% | Selected by latest signal basket | ARKG received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| XYLD | 3.40% | 3.40% | Selected by latest signal basket | XYLD received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| QTEC | 3.40% | 3.40% | Selected by latest signal basket | QTEC received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| PKW | 3.07% | -0.49% | Carryover / turnover-constrained holding | PKW is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EWS | 3.07% | -0.49% | Carryover / turnover-constrained holding | EWS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XOP | 2.78% | -0.44% | Carryover / turnover-constrained holding | XOP is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| VTV | 2.69% | -0.43% | Carryover / turnover-constrained holding | VTV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SGOV | 36.84% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.0820458801498128 | 0.3517322511174223 | 0.3684329009745667 |
| EWT | 8.70% | 27.112 | True | True | True | True | 33.99% | Selected by latest signal basket | 0.1199999997981854 | 1.0933333333333333 | 0.1199999999999999 | 0.1101544943820224 | 0.0830441625967116 | 0.0869871944847498 |
| CIBR | 7.15% | 30.726 | True | True | True | True | 33.08% | Selected by latest signal basket | 0.1199999997729225 | 1.14 | 0.1199999999999999 | 0.1101544943820224 | 0.0682376729114021 | 0.0714776757224586 |
| XBI | 6.56% | 9.179 | False | True | False | True | 28.98% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0626444499797919 | 0.0656188801643491 |
| JQUA | 5.65% | 17.583 | True | True | True | True | 9.76% | Selected by latest signal basket | 0.119999997669357 | 0.9533333333333334 | 0.1199999999999999 | 0.1101544943820224 | 0.0539059633581537 | 0.056465480196307 |
| XLV | 5.49% | 14.499 | True | True | True | True | 17.81% | Selected by latest signal basket | 0.1199999993307248 | 0.8366666666666667 | 0.1125388870530444 | 0.103305535013697 | 0.0524522839680504 | 0.0549427784449572 |
| EWY | 4.07% | 15.522 | True | True | True | True | 59.56% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0388318988633369 | 0.040675681866301 |
| AVDV | 3.72% | 11.844 | False | True | True | True | 14.73% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0355537972208662 | 0.0372419322059045 |
| ARKG | 3.40% | 44.059 | True | True | True | True | 43.83% | Selected by latest signal basket | 0.119999999635634 | 1.163333333333333 | 0.1199999999999999 | 0.1101544943820224 | 0.0324819608051659 | 0.0340242414813257 |
| XYLD | 3.40% | 15.491 | True | True | True | True | 5.39% | Selected by latest signal basket | 0.1199999961947579 | 0.9066666666666668 | 0.1199999999999999 | 0.1101544943820224 | 0.0324819608051659 | 0.0340242414813257 |
| QTEC | 3.40% | 23.933 | True | True | True | True | 28.72% | Selected by latest signal basket | 0.1199999986913745 | 1.07 | 0.1199999999999999 | 0.1101544943820224 | 0.0324819608051659 | 0.0340242414813257 |
| PKW | 3.07% | 10.943 | False | True | True | True | 11.61% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0292987763259816 | 0.0306899157597655 |
| EWS | 3.07% | 16.892 | False | True | True | True | 15.10% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0292987763259816 | 0.0306899157597655 |
| XOP | 2.78% | 11.94 | False | True | True | True | 28.24% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0265402382310375 | 0.027800399118797 |
| VTV | 2.69% | 9.094 | False | True | False | True | 8.28% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0256849691263284 | 0.0269045208581005 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 36.84% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 60.08% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 8.20% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 15.59% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 29.84% | One-way movement at the latest rebalance. |
| Turnover before pruning | 31.01% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 0.00% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 57.60% | 16.98% | 12.77% | 1.135 | -11.45% | 0.0655% | 1.482 | 1.482 | 1.259 | 0.259 | 1.575 |
| SPY | 90.28% | 24.83% | 15.33% | 1.393 | -18.76% | 0.0927% | 1.324 | 1.324 | 1.332 | 0.332 | 2.093 |
| QQQ | 115.46% | 30.29% | 20.51% | 1.296 | -22.77% | 0.1134% | 1.330 | 1.330 | 1.283 | 0.283 | 1.928 |
| VTI | 89.25% | 24.60% | 15.47% | 1.370 | -19.30% | 0.0920% | 1.274 | 1.274 | 1.321 | 0.321 | 2.050 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| PKW | VTV | 0.906 |
| JQUA | VTV | 0.868 |
| JQUA | QTEC | 0.851 |
| JQUA | PKW | 0.849 |
| JQUA | XYLD | 0.827 |
| XBI | ARKG | 0.787 |
| EWT | EWY | 0.763 |
| CIBR | QTEC | 0.758 |
| XYLD | VTV | 0.742 |
| EWT | QTEC | 0.741 |
| CIBR | JQUA | 0.732 |
| XYLD | PKW | 0.723 |
| XYLD | QTEC | 0.722 |
| AVDV | EWS | 0.712 |
| AVDV | VTV | 0.689 |
| JQUA | AVDV | 0.684 |
| XLV | VTV | 0.669 |
| EWT | AVDV | 0.668 |
| EWT | JQUA | 0.652 |
| AVDV | PKW | 0.647 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
