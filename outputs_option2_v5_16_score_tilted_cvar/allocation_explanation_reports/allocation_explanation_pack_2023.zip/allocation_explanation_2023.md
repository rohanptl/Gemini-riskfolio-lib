# V5.16 Allocation Explanation Report

Generated at: `2026-09-01T22:45:00`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-09-01`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| XBI | 11.35% | 1.74% | Selected by latest signal basket | XBI received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| SGOV | 10.95% | -2.94% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| EWT | 9.42% | 2.46% | Selected by latest signal basket | EWT received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| VTV | 8.56% | 2.12% | Selected by latest signal basket | VTV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| THD | 7.39% | -1.99% | Carryover / turnover-constrained holding | THD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| AVUV | 6.91% | -1.86% | Carryover / turnover-constrained holding | AVUV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XOP | 6.69% | 2.99% | Selected by latest signal basket | XOP received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| CIBR | 6.56% | 1.38% | Selected by latest signal basket | CIBR received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EIS | 5.69% | -1.53% | Carryover / turnover-constrained holding | EIS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| XLV | 3.93% | 3.93% | Selected by latest signal basket | XLV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EWS | 3.93% | 3.93% | Selected by latest signal basket | EWS received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| JETS | 3.90% | -1.05% | Carryover / turnover-constrained holding | JETS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| PKW | 3.87% | 3.87% | Selected by latest signal basket | PKW received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| OIH | 3.66% | -0.98% | Carryover / turnover-constrained holding | OIH is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EWY | 3.61% | -0.97% | Carryover / turnover-constrained holding | EWY is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| JQUA | 3.58% | 3.58% | Selected by latest signal basket | JQUA received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| XBI | 11.35% | 24.799 | True | True | True | True | 30.90% | Selected by latest signal basket | 0.097441306189855 | 1.1166666666666667 | 0.1152706952846953 | 0.1152706952846953 | 0.1017183136017037 | 0.1134925167693303 |
| SGOV | 10.95% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.0 | 0.0980973748477786 | 0.1094524433774364 |
| EWT | 9.42% | 26.295 | True | True | True | True | 41.36% | Selected by latest signal basket | 0.1199999989455692 | 1.0933333333333333 | 0.1199999999999999 | 0.1199999999999999 | 0.0843830430865275 | 0.0941506361385885 |
| VTV | 8.56% | 15.327 | True | True | True | True | 9.57% | Selected by latest signal basket | 0.1199999971803202 | 0.8366666666666667 | 0.1063618527297676 | 0.1063618527297676 | 0.076747220727841 | 0.0856309441932009 |
| THD | 7.39% | 7.354 | False | True | False | True | 18.44% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0662354410697237 | 0.0739023941722496 |
| AVUV | 6.91% | 13.058 | False | True | True | True | 11.77% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.061895651292824 | 0.0690602605722102 |
| XOP | 6.69% | 17.242 | True | True | True | True | 29.32% | Selected by latest signal basket | 0.119999999768975 | 0.9066666666666668 | 0.1152606531573577 | 0.1152606531573577 | 0.0599858499652482 | 0.0669293939512328 |
| CIBR | 6.56% | 28.286 | True | True | True | True | 32.99% | Selected by latest signal basket | 0.0625586670233781 | 1.14 | 0.0755517626628604 | 0.0755517626628604 | 0.0587850289046068 | 0.0655895742124249 |
| EIS | 5.69% | -5.333 | True | False | False | False | 26.88% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0509958396664533 | 0.0568987627063264 |
| XLV | 3.93% | 16.22 | True | True | True | True | 19.46% | Selected by latest signal basket | 0.1199999961889431 | 0.9533333333333334 | 0.1199999999999999 | 0.1199999999999999 | 0.0352379944595941 | 0.0393168991454462 |
| EWS | 3.93% | 22.255 | True | True | True | True | 15.89% | Selected by latest signal basket | 0.119999995893664 | 1.07 | 0.1199999999999999 | 0.1199999999999999 | 0.0352379944595941 | 0.0393168991454462 |
| JETS | 3.90% | 4.116 | False | False | True | True | 33.57% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0349318334826664 | 0.0389752991072845 |
| PKW | 3.87% | 16.317 | True | True | True | True | 11.12% | Selected by latest signal basket | 0.1199999763460157 | 0.93 | 0.1182269191122064 | 0.1182269191122064 | 0.0347173293387567 | 0.0387359654584287 |
| OIH | 3.66% | 6.641 | True | True | False | True | 32.17% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0328129279009121 | 0.036611123780789 |
| EWY | 3.61% | 3.795 | True | True | False | True | 76.96% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0323696478051643 | 0.0361165326701149 |
| JQUA | 3.58% | 16.494 | True | True | True | True | 13.36% | Selected by latest signal basket | 0.1199999744846727 | 0.86 | 0.1093281170531124 | 0.1093281170531124 | 0.0321041965249619 | 0.0358203545994896 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 10.95% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 76.62% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 0.00% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 11.55% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 26.01% | One-way movement at the latest rebalance. |
| Turnover before pruning | 20.00% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 6.01% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 71.72% | 21.19% | 15.19% | 1.210 | -12.97% | 0.0809% | 1.634 | 1.634 | 1.271 | 0.271 | 1.730 |
| SPY | 86.42% | 24.78% | 15.45% | 1.381 | -18.76% | 0.0926% | 1.321 | 1.321 | 1.330 | 0.330 | 2.069 |
| QQQ | 101.41% | 28.26% | 20.64% | 1.212 | -22.77% | 0.1072% | 1.241 | 1.241 | 1.264 | 0.264 | 1.795 |
| VTI | 86.17% | 24.72% | 15.59% | 1.367 | -19.30% | 0.0925% | 1.281 | 1.281 | 1.321 | 0.321 | 2.040 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| VTV | PKW | 0.907 |
| AVUV | PKW | 0.880 |
| VTV | JQUA | 0.869 |
| PKW | JQUA | 0.852 |
| VTV | AVUV | 0.835 |
| XOP | OIH | 0.809 |
| EWT | EWY | 0.761 |
| AVUV | JQUA | 0.760 |
| CIBR | JQUA | 0.742 |
| JETS | PKW | 0.712 |
| AVUV | JETS | 0.698 |
| AVUV | OIH | 0.685 |
| VTV | XLV | 0.672 |
| EWT | JQUA | 0.657 |
| JETS | JQUA | 0.656 |
| VTV | JETS | 0.655 |
| EWS | JQUA | 0.627 |
| EIS | JQUA | 0.599 |
| VTV | OIH | 0.597 |
| VTV | EWS | 0.591 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
