# V5.16 Allocation Explanation Report

Generated at: `2026-08-09T17:46:15`

Output folder: `outputs_option2_v5_16_score_tilted_cvar`  
Window folder: `outputs_option2_v5_16_score_tilted_cvar/walk_forward_windows/2023`  
Walk-forward window: `2023`  
Latest rebalance date: `2026-08-07`

## One-paragraph explanation

V5.16 is a monthly ETF allocation model. It starts with the Wealthfront ETF universe, downloads price data, ranks ETFs using trend, momentum, and volatility signals, removes weak or highly correlated choices, uses Riskfolio's CVaR optimizer to size the selected basket, modestly tilts weights toward higher-scoring ETFs, adds `SGOV` as a cash/T-bill sleeve when risk is elevated, applies a 20% monthly turnover cap, removes tiny positions, and then holds the final weights until the next monthly rebalance.

## Final allocation and plain-English reasons

| Ticker | FinalWeightPct | WeightChangePct | SelectionBucket | PlainEnglishExplanation |
| --- | --- | --- | --- | --- |
| XBI | 11.69% | 2.19% | Selected by latest signal basket | XBI received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EWT | 10.81% | 2.37% | Selected by latest signal basket | EWT received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| CIBR | 8.97% | 2.76% | Selected by latest signal basket | CIBR received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| MLPA | 8.95% | -1.89% | Carryover / turnover-constrained holding | MLPA is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| VTV | 7.43% | 3.09% | Selected by latest signal basket | VTV received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| DIV | 6.95% | -1.47% | Carryover / turnover-constrained holding | DIV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| SGOV | 6.57% | -1.39% | Cash / risk-control sleeve | SGOV is the cash/T-bill sleeve. The model uses it when it does not want the full portfolio in risk ETFs, usually because market breadth is weaker or the selected ETF basket is too volatile. |
| EIS | 5.45% | -1.15% | Carryover / turnover-constrained holding | EIS is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| AVUV | 5.35% | -1.13% | Carryover / turnover-constrained holding | AVUV is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| SPYD | 5.29% | -1.12% | Carryover / turnover-constrained holding | SPYD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| OIH | 4.01% | -0.85% | Carryover / turnover-constrained holding | OIH is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| EWS | 3.85% | 3.85% | Selected by latest signal basket | EWS received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| EWI | 3.85% | 3.85% | Selected by latest signal basket | EWI received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| KIE | 3.72% | 3.72% | Selected by latest signal basket | KIE received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |
| THD | 3.57% | -0.76% | Carryover / turnover-constrained holding | THD is likely a carryover holding. It may remain because V5.16 limits monthly turnover, so the portfolio does not fully replace old positions in one rebalance. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Carryover/kept holding from prior rebalance; still above pruning threshold. |
| BBCA | 3.54% | 3.54% | Selected by latest signal basket | BBCA received an allocation because it passed the latest ETF selection process, survived the diversification/correlation filter, and then received a weight from CVaR risk sizing plus the score tilt. Main positives: above medium-term trend, above longer-term trend, positive 3-month momentum, positive 6-month momentum. Saved model note: Current eligible ETF selected by the V5.7/V5.9b signal layer. |

## Signal details behind each holding

| Ticker | FinalWeightPct | Score | AboveSMA50 | AboveSMA126 | PositiveMom63 | PositiveMom126 | Vol63AnnPct | SelectionBucket | OptimizerRawWeight | ScoreTiltMultiplier | RiskWeightAfterScoreTilt | CashScaledTargetWeight | WeightAfterTurnoverCapBeforePrune | WeightAfterPruningFinal |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| XBI | 11.69% | 22.585 | True | True | True | True | 30.19% | Selected by latest signal basket | 0.1199999996791827 | 1.0933333333333333 | 0.12 | 0.12 | 0.1019950491045697 | 0.1168744315436911 |
| EWT | 10.81% | 27.373 | True | True | True | True | 44.68% | Selected by latest signal basket | 0.11999999973716 | 1.1166666666666667 | 0.12 | 0.12 | 0.0943723744022743 | 0.1081397352962305 |
| CIBR | 8.97% | 34.343 | True | True | True | True | 32.46% | Selected by latest signal basket | 0.1199999995942533 | 1.163333333333333 | 0.12 | 0.12 | 0.0783191481860118 | 0.0897446101902619 |
| MLPA | 8.95% | 14.025 | True | True | True | True | 15.35% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0780900212109335 | 0.0894820573977618 |
| VTV | 7.43% | 15.579 | True | True | True | True | 9.90% | Selected by latest signal basket | 0.1199999998007957 | 0.93 | 0.12 | 0.12 | 0.0648750648216629 | 0.0743392585126198 |
| DIV | 6.95% | 12.171 | True | True | True | True | 11.42% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0606371733114124 | 0.0694831290675861 |
| SGOV | 6.57% |  |  |  |  |  | n/a | Cash / risk-control sleeve | 0.0 |  | 0.0 | 0.0 | 0.0573145805858569 | 0.0656758252870627 |
| EIS | 5.45% | -1.208 | True | False | False | True | 27.68% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0475301378484298 | 0.0544639949781605 |
| AVUV | 5.35% | 14.731 | True | True | True | True | 12.96% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0466979611206962 | 0.0535104174971786 |
| SPYD | 5.29% | 14.227 | True | True | True | True | 12.36% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0461585083412811 | 0.0528922675233092 |
| OIH | 4.01% | -2.144 | False | False | False | True | 30.79% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0349709019069422 | 0.0400725752556251 |
| EWS | 3.85% | 21.081 | True | True | True | True | 14.88% | Selected by latest signal basket | 0.1199999988427172 | 1.07 | 0.12 | 0.12 | 0.0335673872925321 | 0.0384643111863146 |
| EWI | 3.85% | 16.422 | True | True | True | True | 17.71% | Selected by latest signal basket | 0.1199999996585186 | 0.9766666666666668 | 0.12 | 0.12 | 0.0335673872925321 | 0.0384643111863146 |
| KIE | 3.72% | 15.71 | True | True | True | True | 20.86% | Selected by latest signal basket | 0.1199999998785218 | 0.8833333333333333 | 0.1161147129210776 | 0.1161147129210776 | 0.0324805628248582 | 0.0372189370925493 |
| THD | 3.57% | 15.067 | True | True | True | True | 19.99% | Carryover / turnover-constrained holding | 0.0 |  | 0.0 | 0.0 | 0.0311833531316317 | 0.0357324860655648 |
| BBCA | 3.54% | 15.502 | True | True | True | True | 11.81% | Selected by latest signal basket | 0.1105204315530159 | 0.9066666666666668 | 0.1105699829062696 | 0.1105699829062696 | 0.030929545326195 | 0.0354416519197687 |

## Cash / SGOV explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Final cash / SGOV weight | 6.57% | How much of the portfolio is parked in the cash/T-bill sleeve. |
| Signal breadth | 84.52% | How broad the market strength was across the ETF universe. |
| Breadth-driven cash | 0.00% | Cash suggested because not enough ETFs had strong signals. |
| Volatility-driven cash | 0.00% | Cash suggested because the selected risk sleeve was too volatile. |
| Active sleeve volatility | 13.15% | Estimated annualized volatility of the selected ETF basket. |
| Eligible ETF count | 15 | Number of ETFs that passed the latest selection process. |

## Turnover explanation

| Item | Value | Plain English |
| --- | --- | --- |
| Latest turnover | 25.37% | One-way movement at the latest rebalance. |
| Turnover before pruning | 20.00% | How much the model wanted to move before cleaning up tiny positions. |
| Extra turnover from pruning | 5.37% | Additional movement caused by removing very small positions. |

## Performance context

| Measure | Short description |
| --- | --- |
| EV | Expected Value: the strategy's average return per trading day. Higher is better. |
| MAR | Full-history CAGR divided by the absolute maximum drawdown. Higher means more return per unit of historical drawdown. |
| Calmar | Annualized return over the latest three trading years divided by the maximum drawdown over that period. Higher is better. |
| PF | Profit Factor: gross positive daily returns divided by gross negative daily returns. Above 1.0 means gains exceeded losses. |
| GtP | Gain-to-Pain ratio: net daily returns divided by gross negative daily returns. Higher positive values indicate a better payoff relative to losses. |
| Sortino | Annualized excess return divided by downside deviation. Higher means better return relative to harmful volatility. |

### Strategy and benchmark comparison

| Name | Total Return | CAGR | Annual Volatility | Sharpe | Max Drawdown | EV | MAR | Calmar | PF | GtP | Sortino |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Strategy | 90.44% | 25.69% | 15.60% | 1.416 | -13.38% | 0.0956% | 1.920 | 1.920 | 1.323 | 0.323 | 1.993 |
| SPY | 86.20% | 24.69% | 15.55% | 1.368 | -18.76% | 0.0924% | 1.316 | 1.316 | 1.324 | 0.324 | 2.044 |
| QQQ | 101.42% | 28.21% | 20.74% | 1.205 | -22.77% | 0.1072% | 1.239 | 1.239 | 1.261 | 0.261 | 1.780 |
| VTI | 85.80% | 24.59% | 15.71% | 1.351 | -19.30% | 0.0922% | 1.274 | 1.274 | 1.314 | 0.314 | 2.012 |

## Correlation / overlap context

The table below shows highly correlated final holdings if the strategy output file exists. High correlation means two ETFs may move similarly, but it does not automatically mean one must be removed because the model also considers score, risk, and turnover.

| ETF 1 | ETF 2 | Correlation |
| --- | --- | --- |
| DIV | SPYD | 0.902 |
| VTV | SPYD | 0.852 |
| VTV | AVUV | 0.836 |
| VTV | DIV | 0.798 |
| AVUV | SPYD | 0.783 |
| DIV | AVUV | 0.776 |
| VTV | BBCA | 0.765 |
| AVUV | BBCA | 0.715 |
| EWI | BBCA | 0.699 |
| EWS | BBCA | 0.697 |
| AVUV | OIH | 0.690 |
| VTV | KIE | 0.685 |
| EWS | EWI | 0.681 |
| SPYD | BBCA | 0.670 |
| DIV | BBCA | 0.662 |
| SPYD | KIE | 0.655 |
| VTV | EWI | 0.645 |
| DIV | KIE | 0.631 |
| MLPA | DIV | 0.608 |
| VTV | OIH | 0.604 |

## How to explain this to a non-technical person

- The model does not simply buy the highest-return ETFs.
- It first checks whether each ETF is in an uptrend and has positive momentum.
- It avoids owning too many ETFs that behave almost the same.
- It uses a risk optimizer to spread the portfolio across the selected ETFs.
- It gives a small extra push to ETFs with stronger scores.
- It parks part of the portfolio in `SGOV` when the opportunity set is not strong enough or when the selected basket is too volatile.
- It limits monthly trading so the portfolio does not churn too aggressively.

## What this report can and cannot prove

This report explains the allocation using files already generated by V5.16.

It can explain:
- final weights,
- trend and momentum reasons,
- cash/SGOV logic,
- turnover impact,
- correlation/overlap context,
- and benchmark performance context.

If `final_allocation_attribution.csv` exists, this report can include raw CVaR weights, score-tilt multipliers, cash-scaled weights, turnover-capped weights, and final pruned weights. If that file does not exist, the report falls back to the older summary-level explanation.

To get that level of detail, the main V5.16 strategy script would need to save an additional internal attribution file during each monthly rebalance.
